<?php 
   $gmailpass = 'Starth84!"'; 
   
?> 