$( document ).ready(function() {
  $(".sidebar-toggle").on("click", function(){
    $(".navbarsection").toggle();
    $("nav").removeClass("navbar");
    $("nav").addClass("navmob");
    $(".mainsec").on("click", function(){
      $(".navbarsection").hide();
      $("nav").addClass("navbar");
      $("nav").removeClass("navmob");
    })
  })
});